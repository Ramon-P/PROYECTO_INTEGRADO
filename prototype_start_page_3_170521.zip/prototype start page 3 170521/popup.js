document.addEventListener("DOMContentLoaded",mein);

function mein(){
	document.getElementById("boton").addEventListener("click",addElement)

// var btnAbrirPopup = document.getElementById('btn-abrir-popup'),
// 	overlay = document.getElementById('overlay'),
// 	popup = document.getElementById('popup'),
// 	btnCerrarPopup = document.getElementById('btn-cerrar-popup');

// btnAbrirPopup.addEventListener('click', function(){
// 	overlay.classList.add('active');
// 	popup.classList.add('active');
// });

// btnCerrarPopup.addEventListener('click', function(e){
// 	e.preventDefault();
// 	overlay.classList.remove('active');
// 	popup.classList.remove('active');
// });


function aranque (){
	document.getElementById("opcioines").style.visibility='collapse';

}
aranque();


function ocultar () {
					
					let botones=document.getElementsByClassName('oculta');
					
					botones [0].addEventListener("click", function(){
						  if (botones [0].innerHTML != 'Usuario:') {

									botones [0].innerHTML = "Usuario:"; 

									
									document.getElementById("opcioines").style.visibility = '';
							}
						  else {
						  	
						  	botones [0].innerHTML = "<img src='perf.png' id='perfil'>"; 

									document.getElementById("opcioines").style.visibility='collapse';
						  }
					});

					
				}

ocultar();



	
	
function addElement () {
    
    var newDiv = document.createElement("div");
    newDiv.setAttribute("class","corcho")
    var newcontenedor = document.createElement("div") ; 
    newcontenedor.setAttribute("class","posit")
  newDiv.appendChild(newcontenedor)

  var newcontenedor2 = document.createElement("div")
  newcontenedor2.setAttribute("class","input-contenedor")
  newcontenedor.appendChild(newcontenedor2)
  var newtextarea = document.createElement("textarea")
  newtextarea.setAttribute("cols","60")
  newtextarea.setAttribute("rows","5")
  newcontenedor2.appendChild(newtextarea)
    // añade el elemento creado y su contenido al DOM
    var currentDiv = document.getElementById("corcho");
    document.body.insertBefore(newDiv, currentDiv);
  }
}
http_path = "/"
css_dir = "."
sass_dir = "."
images_dir = "images/"
http_images_path = "/"

output_style = :expanded

line_comments = true

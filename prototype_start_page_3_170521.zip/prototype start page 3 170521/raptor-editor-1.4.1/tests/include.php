<?php
require_once __DIR__ . '/../../raptor-example/include.php';
require_once RAPTOR_THEMES_DIR . 'include.php';
require_once RAPTOR_DEPENDENCIES_DIR . 'include.php';
require_once RAPTOR_COMMON_DIR . 'include.php';
require_once RAPTOR_LOCALES_DIR . 'include.php';
require_once RAPTOR_EDITOR_DIR . 'src/include.php';
require_once RAPTOR_FILE_MANAGER_DIR . 'src/include.php';
require_once RAPTOR_PREMIUM_DIR . 'src/include.php';
require_once RAPTOR_SECTION_DIR . 'src/include.php';

$.ui.editor.instances[0].uiObjects.textBold.ui.click();

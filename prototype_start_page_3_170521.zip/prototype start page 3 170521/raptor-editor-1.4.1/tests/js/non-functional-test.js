window.testResults = {
    tests: [],
    finished: true
};

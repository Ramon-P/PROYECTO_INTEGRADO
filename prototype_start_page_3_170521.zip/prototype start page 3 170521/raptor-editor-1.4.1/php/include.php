<?php
namespace Raptor;
define('Raptor\ROOT', __DIR__ . '/../');

require_once __DIR__ . '/classes/Raptor/Example.php';
require_once __DIR__ . '/functions/load-raptor.php';
require_once __DIR__ . '/functions/example/load-content.php';
require_once __DIR__ . '/functions/example/head.php';
<?php
function loadRaptor() {
    require_once RAPTOR_COMMON_DIR . 'src/include.php';
    require_once RAPTOR_EDITOR_DIR . 'src/include.php';
    require_once RAPTOR_FILE_MANAGER_DIR . 'src/include.php';
    require_once RAPTOR_GOLD_DIR . 'src/include.php';
}